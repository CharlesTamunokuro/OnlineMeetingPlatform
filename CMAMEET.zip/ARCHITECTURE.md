# VideoMeet Architecture Overview

## System Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                         Client Browser                          │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │              React Frontend Application                 │  │
│  │  ┌──────────────────────────────────────────────────┐   │  │
│  │  │  Landing Page  │  Meeting Room  │  Components  │   │  │
│  │  └──────────────────────────────────────────────────┘   │  │
│  │                                                          │  │
│  │  ┌──────────────────────────────────────────────────┐   │  │
│  │  │  WebRTC Manager  │  Media Stream Handler       │   │  │
│  │  └──────────────────────────────────────────────────┘   │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                 │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │              WebRTC Peer Connections                    │  │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐     │  │
│  │  │ Peer Conn 1 │  │ Peer Conn 2 │  │ Peer Conn N │     │  │
│  │  └─────────────┘  └─────────────┘  └─────────────┘     │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                 │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │              WebSocket Connection                       │  │
│  │  (Signaling: Offers, Answers, ICE Candidates)          │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                 │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │              tRPC Client                                │  │
│  │  (Meeting CRUD, Participant Management)                │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
              │                          │
              │ HTTP/HTTPS              │ WebSocket/WSS
              │ (tRPC)                  │ (Signaling)
              ▼                          ▼
┌─────────────────────────────────────────────────────────────────┐
│                    Backend Server (Node.js)                     │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │              Express.js HTTP Server                     │  │
│  │  ┌──────────────────────────────────────────────────┐   │  │
│  │  │  tRPC Router  │  OAuth Routes  │  Static Files │   │  │
│  │  └──────────────────────────────────────────────────┘   │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                 │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │              WebSocket Server (ws library)              │  │
│  │  ┌──────────────────────────────────────────────────┐   │  │
│  │  │  Signaling Server  │  Room Management          │   │  │
│  │  │  - Offer/Answer    │  - Participant Tracking   │   │  │
│  │  │  - ICE Candidates  │  - Connection Routing     │   │  │
│  │  └──────────────────────────────────────────────────┘   │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                 │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │              Database Layer (Drizzle ORM)              │  │
│  │  ┌──────────────────────────────────────────────────┐   │  │
│  │  │  Users  │  Meetings  │  Participants           │   │  │
│  │  └──────────────────────────────────────────────────┘   │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
              │
              │ MySQL Protocol
              ▼
┌─────────────────────────────────────────────────────────────────┐
│                    MySQL/TiDB Database                          │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  users  │  meetings  │  participants  │  sessions       │  │
│  └──────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘
```

## Data Flow Diagram

### Meeting Creation Flow

```
User clicks "Create Meeting"
         │
         ▼
Frontend: Show title input dialog
         │
         ▼
User enters title and confirms
         │
         ▼
Frontend: Call trpc.meetings.create mutation
         │
         ▼
Backend: Generate unique meeting ID
         │
         ▼
Backend: Insert meeting into database
         │
         ▼
Backend: Return meeting ID to frontend
         │
         ▼
Frontend: Redirect to /meeting/{meetingId}
         │
         ▼
Meeting Room initialized
```

### Meeting Join Flow

```
User clicks "Join Meeting"
         │
         ▼
Frontend: Show join dialog
         │
         ▼
User enters meeting ID and name
         │
         ▼
Frontend: Call trpc.meetings.join mutation
         │
         ▼
Backend: Validate meeting exists and is active
         │
         ▼
Backend: Insert participant into database
         │
         ▼
Backend: Return participant ID to frontend
         │
         ▼
Frontend: Redirect to /meeting/{meetingId}
         │
         ▼
Meeting Room initialized
```

### WebRTC Peer Connection Flow

```
Participant A joins meeting
         │
         ▼
WebSocket: Broadcast "participant-joined" to existing participants
         │
         ▼
Participant B receives "participant-joined"
         │
         ▼
Participant B: Create RTCPeerConnection
         │
         ▼
Participant B: Add local media tracks
         │
         ▼
Participant B: Create SDP offer
         │
         ▼
WebSocket: Send offer to Participant A
         │
         ▼
Participant A: Receive offer
         │
         ▼
Participant A: Create RTCPeerConnection
         │
         ▼
Participant A: Set remote description (offer)
         │
         ▼
Participant A: Create SDP answer
         │
         ▼
WebSocket: Send answer to Participant B
         │
         ▼
Participant B: Receive answer
         │
         ▼
Participant B: Set remote description (answer)
         │
         ▼
ICE Candidate Exchange (both directions)
         │
         ▼
Direct P2P Connection Established
         │
         ▼
Media Streams Flow Between Participants
```

## Component Architecture

### Frontend Components

```
App
├── Router
│   ├── Home (Landing Page)
│   │   ├── Header
│   │   ├── Hero Section
│   │   ├── Action Cards
│   │   │   ├── Create Meeting Card
│   │   │   └── Join Meeting Card
│   │   ├── Features Section
│   │   ├── Create Meeting Dialog
│   │   └── Join Meeting Dialog
│   │
│   └── MeetingRoom
│       ├── Header
│       │   ├── Meeting ID Display
│       │   └── Copy Button
│       ├── Main Content
│       │   ├── Video Grid
│       │   │   ├── Local Video Card
│       │   │   └── Remote Video Cards (N)
│       │   ├── Control Bar
│       │   │   ├── Mute/Unmute Button
│       │   │   ├── Camera On/Off Button
│       │   │   └── Leave Meeting Button
│       │   └── Participants Sidebar
│       │       ├── Participant List
│       │       └── Status Indicators
│       └── Leave Meeting Dialog
│
└── Providers
    ├── ThemeProvider
    ├── TooltipProvider
    └── Toaster
```

### Backend Modules

```
server/
├── _core/
│   ├── index.ts (Main server entry)
│   ├── context.ts (tRPC context)
│   ├── trpc.ts (tRPC setup)
│   ├── oauth.ts (OAuth integration)
│   └── vite.ts (Vite dev server)
├── signaling.ts (WebSocket signaling server)
├── routers.ts (tRPC procedures)
├── db.ts (Database queries)
└── auth.logout.test.ts (Tests)
```

## Database Schema

```
users
├── id (PK)
├── openId (UNIQUE)
├── name
├── email
├── loginMethod
├── role (enum: user, admin)
├── createdAt
├── updatedAt
└── lastSignedIn

meetings
├── id (PK)
├── meetingId (UNIQUE)
├── hostId (FK → users.id)
├── title
├── status (enum: active, ended)
├── createdAt
└── endedAt

participants
├── id (PK)
├── meetingId (FK → meetings.id)
├── userId (FK → users.id, nullable)
├── displayName
├── joinedAt
├── leftAt
├── audioEnabled (boolean)
└── videoEnabled (boolean)
```

## Technology Stack Summary

| Layer | Technology | Purpose |
|-------|-----------|---------|
| Frontend | React 19 | UI framework |
| Styling | Tailwind CSS 4 | Utility-first CSS |
| Real-time Communication | WebRTC | P2P video/audio |
| Signaling | WebSocket (ws) | Peer coordination |
| API | tRPC 11 | Type-safe RPC |
| Backend | Express.js 4 | HTTP server |
| Runtime | Node.js 22 | JavaScript runtime |
| Database | MySQL/TiDB | Data persistence |
| ORM | Drizzle | Type-safe queries |
| Testing | Vitest | Unit testing |
| Build | Vite | Frontend bundler |
| Package Manager | pnpm | Dependency management |

## Deployment Architecture

```
┌──────────────────────────────────────────┐
│         Load Balancer (Optional)         │
└──────────────────────────────────────────┘
              │
              ├─────────────────┬─────────────────┐
              ▼                 ▼                 ▼
┌──────────────────────┐ ┌──────────────────────┐ ┌──────────────────────┐
│  Server Instance 1   │ │  Server Instance 2   │ │  Server Instance N   │
│  (Node.js + Express) │ │  (Node.js + Express) │ │  (Node.js + Express) │
└──────────────────────┘ └──────────────────────┘ └──────────────────────┘
              │                 │                 │
              └─────────────────┴─────────────────┘
                        │
                        ▼
              ┌──────────────────────┐
              │  Database (MySQL)    │
              │  (Replicated)        │
              └──────────────────────┘
```

## Security Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                     HTTPS/WSS Encryption                    │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌──────────────────────────────────────────────────────┐  │
│  │              OAuth Authentication                   │  │
│  │  (Manus OAuth for secure user identity)             │  │
│  └──────────────────────────────────────────────────────┘  │
│                                                             │
│  ┌──────────────────────────────────────────────────────┐  │
│  │              Session Management                     │  │
│  │  (HTTP-only, SameSite cookies)                      │  │
│  └──────────────────────────────────────────────────────┘  │
│                                                             │
│  ┌──────────────────────────────────────────────────────┐  │
│  │              Input Validation                       │  │
│  │  (Client-side and server-side)                      │  │
│  └──────────────────────────────────────────────────────┘  │
│                                                             │
│  ┌──────────────────────────────────────────────────────┐  │
│  │              DTLS-SRTP Encryption                   │  │
│  │  (WebRTC media encryption)                          │  │
│  └──────────────────────────────────────────────────────┘  │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

**Document Version**: 1.0  
**Last Updated**: March 14, 2026  
**Author**: Manus AI
